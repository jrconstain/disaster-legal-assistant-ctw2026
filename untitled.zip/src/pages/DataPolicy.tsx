import React from 'react';

export default function DataPolicy() {
  return (
    <section className="section" style={{ minHeight: '80vh', paddingTop: '4rem' }}>
      <div className="container">
        <h1>Política de Datos y Uso</h1>
        <span className="eyebrow">Transparencia y privacidad</span>
        
        <div style={{ marginTop: '2rem', maxWidth: 'var(--reading-w)' }}>
          <h3 className="mb-2">Marco Legal y Autorización</h3>
          <p>
            En estricto cumplimiento del <strong>Artículo 15 de la Constitución Política de Colombia</strong>, la <strong>Ley Estatutaria 1581 de 2012</strong> (Ley General de Protección de Datos Personales o <em>Habeas Data</em>), el Decreto 1377 de 2013 y demás normas que los modifiquen o reglamenten, garantizamos el derecho fundamental de los usuarios a conocer, actualizar, rectificar y suprimir la información personal recopilada. Al interactuar con el asistente Jovita (un MVP en contexto de hackathon), usted otorga su autorización previa, expresa e informada para el tratamiento temporal de sus datos bajo estos términos.
          </p>

          <h3 className="mb-2 mt-8">¿Qué datos recolectamos?</h3>
          <p>
            Para poder asistirle adecuadamente, recolectamos de manera temporal:
          </p>
          <ul>
            <li>Su número de teléfono (necesario para la comunicación vía WhatsApp).</li>
            <li>El historial de chat generado durante su interacción con el asistente.</li>
            <li>Los documentos, audios y fotografías que usted envíe voluntariamente.</li>
          </ul>

          <h3 className="mb-2 mt-8">¿Cómo utilizamos su información?</h3>
          <p>
            Los datos son procesados exclusivamente para:
          </p>
          <ul>
            <li>Determinar la ruta de atención correspondiente a su caso.</li>
            <li>Extraer información clave para evitar preguntas repetitivas.</li>
            <li>Generar documentos y guías de acción (como reclamaciones o solicitudes).</li>
          </ul>
          <p>
            Nuestros modelos de lenguaje (LLMs) procesan su información para entender su situación y ayudarle. Sus datos <strong>no</strong> son utilizados para entrenar modelos públicos ni se comparten con terceros con fines comerciales.
          </p>

          <h3 className="mb-2 mt-8">Sus Derechos (Habeas Data) y supresión de información</h3>
          <p>
            En ejercicio de sus derechos legales como titular de la información (conocer, actualizar, rectificar y solicitar la supresión de sus datos), y dada la naturaleza de este MVP, usted tiene control absoluto sobre su información. Si desea ejercer su derecho a la supresión para que todo registro de su caso, incluyendo historial de mensajes y documentos, sea eliminado de forma permanente, envíe un mensaje en el mismo chat de WhatsApp indicando: <em>"Por favor, borrar mis datos"</em>. Su caso será cerrado y todos sus archivos purgados, respetando el principio de libertad y finalidad de la Ley 1581 de 2012.
          </p>

          <h3 className="mb-2 mt-8">Límites y Responsabilidad (Aviso Legal)</h3>
          <p>
            Jovita es un experimento tecnológico y <strong>no constituye asesoría legal, técnica o profesional</strong>. No diagnosticamos daños, ni garantizamos indemnizaciones. Las respuestas y documentos generados son ayudas de redacción y deben ser revisados bajo su propio criterio antes de ser utilizados.
          </p>
        </div>
      </div>
    </section>
  );
}
